import Dashboard from '../components/Dashboard';

const EmployerDashboard = () => {
  return <Dashboard userType="employer" />;
};

export default EmployerDashboard;
