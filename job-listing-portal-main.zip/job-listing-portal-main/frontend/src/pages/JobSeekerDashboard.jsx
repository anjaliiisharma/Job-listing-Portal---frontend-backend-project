import Dashboard from '../components/Dashboard';

const JobSeekerDashboard = () => {
  return <Dashboard userType="jobseeker" />;
};

export default JobSeekerDashboard;
